document.addEventListener("DOMContentLoaded", () => {
  console.log("✅ Backend status page loaded successfully!");
});
