import React, { useState, useEffect, useMemo } from 'react';
import {
  ComposedChart,
  Line,
  Area,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  Legend,
  ReferenceLine,
  Brush, // Import Brush
} from 'recharts';

interface MonitoringLog {
  _id: string;
  status: string;
  responseTime: number;
  createdAt: string;
}

interface MonitoringService {
  _id: string;
  name: string;
  target: string;
  serviceType: string;
  status: string;
  latestLog?: MonitoringLog;
  logs: MonitoringLog[];
}

interface RealTimeChartProps {
  services?: MonitoringService[];
}

const IDEAL_RESPONSE_TIME = 300; // ms
const ACTION_NEEDED_RESPONSE_TIME = 700; // ms

const roundToNearest5Minutes = (date: Date) => {
  const minutes = 5;
  const ms = 1000 * 60 * minutes;
  return new Date(Math.round(date.getTime() / ms) * ms);
};

const RealTimeChart: React.FC<RealTimeChartProps> = ({ services }) => {
  const [data, setData] = useState<any[]>([]);

  const chartServices = useMemo(() => {
    if (services && services.length > 0) {
      return services;
    }
    return [];
  }, [services]);

  const serviceColors = useMemo(() => {
    // Updated professional and distinct color palette
    const colors = ["#1a9e9e", "#66b2b2", "#3366cc", "#6699cc", "#99ccff", "#ff9933", "#ffcc66", "#cc6699", "#993366", "#663399"];
    return chartServices.reduce((acc, service, index) => {
      acc[service.name] = colors[index % colors.length];
      return acc;
    }, {} as Record<string, string>);
  }, [chartServices]);

  useEffect(() => {
    const timeMap = new Map<number, any>();
    const twentyFourHoursAgo = new Date();
    twentyFourHoursAgo.setDate(twentyFourHoursAgo.getDate() - 1);

    chartServices.forEach(service => {
      if (service.logs) {
        service.logs
          .filter(log => new Date(log.createdAt) > twentyFourHoursAgo)
          .forEach(log => {
            const roundedDate = roundToNearest5Minutes(new Date(log.createdAt));
            const timeKey = roundedDate.getTime();

            if (!timeMap.has(timeKey)) {
              timeMap.set(timeKey, { time: timeKey });
            }
            const entry = timeMap.get(timeKey);
            entry[service.name] = log.responseTime;

            if (log.responseTime > ACTION_NEEDED_RESPONSE_TIME) {
              entry[`${service.name}-excess`] = log.responseTime;
            }
          });
      }
    });

    const sortedData = Array.from(timeMap.values()).sort((a, b) => a.time - b.time);

    const chartData = sortedData.map(d => ({
      ...d,
      time: new Date(d.time).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
    }));

    setData(chartData);
  }, [chartServices]);


  if (chartServices.length === 0) {
    return <div className="flex items-center justify-center h-full text-muted-foreground">No data to display</div>;
  }

  return (
    <ResponsiveContainer width="100%" height="100%">
      <ComposedChart data={data}>
        <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--muted))" />
        <XAxis dataKey="time" stroke="hsl(var(--muted-foreground))" fontSize={12} />
        <YAxis stroke="hsl(var(--muted-foreground))" fontSize={12} unit="ms" />
        <Tooltip
          contentStyle={{
            backgroundColor: "hsl(var(--background))",
            borderColor: "hsl(var(--border))",
          }}
          formatter={(value: any, name: string) => {
            if (typeof value === 'number') {
              return [`${value.toFixed(2)} ms`, name];
            }
            return [value, name];
          }}
        />
        <Legend wrapperStyle={{ fontSize: '14px' }} />
        
        <Brush
          dataKey="time"
          height={30}
          stroke="hsl(var(--primary))"
          fill="hsl(var(--muted))"
          travellerWidth={10}
          gap={5}
        />
        
        <ReferenceLine
          y={IDEAL_RESPONSE_TIME}
          label={{ value: 'Ideal', position: 'insideTopRight', fill: 'hsl(var(--success))' }}
          stroke="hsl(var(--success))"
          strokeDasharray="4 4"
        />

        <ReferenceLine
          y={ACTION_NEEDED_RESPONSE_TIME}
          label={{ value: 'Action Needed', position: 'insideTopRight', fill: 'hsl(var(--destructive))' }}
          stroke="hsl(var(--destructive))"
          strokeDasharray="4 4"
        />

        {chartServices.map(service => (
          <React.Fragment key={service.name}>
            <Line
              type="monotone"
              dataKey={service.name}
              name={service.name}
              stroke={serviceColors[service.name]}
              strokeWidth={2}
              dot={false}
              activeDot={{ r: 6 }}
              connectNulls
            />
            <Area
              type="monotone"
              dataKey={`${service.name}-excess`}
              fill="hsl(var(--destructive))" // Changed from #ef4444 to use theme variable
              fillOpacity={0.3}
              stroke="none"
              baseValue={ACTION_NEEDED_RESPONSE_TIME}
              connectNulls={false}
              legendType="none"
              tooltipType="none"
            />
          </React.Fragment>
        ))}
      </ComposedChart>
    </ResponsiveContainer>
  );
};

export default RealTimeChart;