// export const API_BASE_URL = '/api';
export const API_BASE_URL = 'https://pulse-monitor-backend.onrender.com';
// export const API_BASE_URL = 'http://localhost:5000';
