const ANALYTICS_URL = "/api/v1/traffic";
